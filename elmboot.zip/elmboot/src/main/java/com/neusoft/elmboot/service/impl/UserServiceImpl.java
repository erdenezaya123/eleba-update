package com.neusoft.elmboot.service.impl;

import com.neusoft.elmboot.service.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neusoft.elmboot.mapper.UserMapper;
import com.neusoft.elmboot.po.User;
import com.neusoft.elmboot.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private UserMapper userMapper;

	@Override
	public String login(String username, String password) {

		User user = userMapper.findByUsername(username);
		if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
			throw new IllegalArgumentException("Invalid username or password");
		}
		return jwtUtil.generateToken(user.getUserId());
	}

	@Override
	public String getUserIdFromToken(String token) {
		return jwtUtil.parseToken(token);
	}



	@Override
	public User getUserByIdByPass(User user) {
		return userMapper.getUserByIdByPass(user);
	}
	
	@Override
	public int getUserById(String userId) {
		return userMapper.getUserById(userId);
	}
	
	@Override
	public int saveUser(User user) {
		return userMapper.saveUser(user);
	}
}
