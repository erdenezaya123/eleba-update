package com.neusoft.elmboot.po;

public class TokenRequest {
    private String token;

    // getters and setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
