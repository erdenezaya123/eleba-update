package com.neusoft.elmboot.service;

public interface JwtUtil {
    String generateToken(String userId);
    String parseToken(String token);
}

