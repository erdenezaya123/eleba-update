package com.neusoft.elmboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.neusoft.elmboot.po.User;
import com.neusoft.elmboot.service.UserService;
import com.neusoft.elmboot.po.LoginRequest;
import com.neusoft.elmboot.po.TokenRequest;

@RestController
@RequestMapping("/UserController")
public class UserController {
	
	@Autowired
	private UserService userService;

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
		String token = userService.login(loginRequest.getUsername(), loginRequest.getPassword());
		return ResponseEntity.ok(token);
	}
	@PostMapping("/verifyToken")
	public ResponseEntity<?> verifyToken(@RequestBody TokenRequest tokenRequest) {
		String userId = userService.getUserIdFromToken(tokenRequest.getToken());
		return ResponseEntity.ok(userId);
	}

	@RequestMapping("/getUserByIdByPass")
	public User getUserByIdByPass(User user) throws Exception{
		return userService.getUserByIdByPass(user);
	}
	
	@RequestMapping("/getUserById")
	public int getUserById(User user) throws Exception{
		return userService.getUserById(user.getUserId());
	}
	
	@RequestMapping("/saveUser")
	public int saveUser(User user) throws Exception{
		return userService.saveUser(user);
	}
}
