package com.neusoft.elmboot.service;

import com.neusoft.elmboot.po.User;

public interface UserService {

	String login(String username, String password);

	String getUserIdFromToken(String token);

	public User getUserByIdByPass(User user);
	public int getUserById(String userId);
	public int saveUser(User user);
}
